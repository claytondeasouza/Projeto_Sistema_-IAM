CREATE TABLE registro_acessos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_usuario TEXT NOT NULL,
    matricula TEXT NOT NULL,
    cargo TEXT,
    departamento TEXT,
    tipo_solicitacao TEXT NOT NULL,
    gestor TEXT,
    licenca TEXT,
    status TEXT,
    aprovado_por TEXT,
    data_solicitacao DATETIME,
    data_aprovacao DATETIME,
    data_execucao DATETIME,
    erro_execucao TEXT
);
