// Validação Bootstrap
(() => {
  'use strict'
  const forms = document.querySelectorAll('.needs-validation')
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }
      form.classList.add('was-validated')
    }, false)
  })
})();

// Adicionar linha
function adicionarLinha(tabelaId, prefixoNome) {
  const tabela = document.getElementById(tabelaId).querySelector('tbody');
  const linha = tabela.rows[0].cloneNode(true);
  const novoIndice = tabela.rows.length;
  linha.querySelectorAll('input, select, textarea').forEach(input => {
    const oldName = input.getAttribute('name');
    if (oldName) {
      const newName = oldName.replace(/\[\d+\]/, `[${novoIndice}]`);
      input.setAttribute('name', newName);
      input.value = '';
    }
  });
  linha.querySelectorAll('.form-control').forEach(input => {
      input.classList.remove('is-invalid', 'is-valid');
  });
  tabela.appendChild(linha);
}

// Event listener global para remover linhas e outras interações futuras
document.addEventListener('click', function(e) {
  // Remover linha
  if (e.target.classList.contains('remover-linha')) {
    const linha = e.target.closest('tr');
    const tbody = linha.parentElement;
    if (tbody.rows.length > 1) {
        tbody.removeChild(linha);
    } else {
        linha.querySelectorAll('input').forEach(input => input.value = '');
    }
  }
});

// Lógica para tipo de solicitação (Desligamento)
document.querySelectorAll('input[name="tipo_solicitacao"]').forEach(radio => {
    radio.addEventListener('change', () => {
        const desligamentoSelecionado = document.getElementById('desligamento').checked;
        const campoDemissao = document.getElementById('campo-demissao');
        const dataDemissaoInput = document.getElementById('data_demissao');
        const acaoInputs = document.querySelectorAll('[name$="[acao]"]');
        if (desligamentoSelecionado) {
            campoDemissao.classList.remove('d-none');
            dataDemissaoInput.required = true;
            acaoInputs.forEach(input => { input.value = 'Remover'; });
        } else {
            campoDemissao.classList.add('d-none');
            dataDemissaoInput.required = false;
            dataDemissaoInput.value = '';
            // Limpa o valor 'Remover' se outra opção for selecionada
            acaoInputs.forEach(input => {
                if(input.value === 'Remover') input.value = '';
            });
        }
    });
});

// Lógica para tipo de vínculo (Terceirizado)
document.querySelectorAll('input[name="tipo_vinculo"]').forEach(radio => {
    radio.addEventListener('change', (event) => {
        const camposTerceirizado = document.getElementById('campos-terceirizado');
        const consultoriaInput = document.getElementById('nome_consultoria');
        const gestorConsultoriaInput = document.getElementById('gestor_consultoria');
        if (event.target.value === 'Terceirizado') {
            // No seu HTML, a div já tem a classe 'row', então não precisa de 'd-flex'
            camposTerceirizado.classList.remove('d-none');
            consultoriaInput.required = true;
            gestorConsultoriaInput.required = true;
        } else {
            camposTerceirizado.classList.add('d-none');
            consultoriaInput.required = false;
            gestorConsultoriaInput.required = false;
            consultoriaInput.value = '';
            gestorConsultoriaInput.value = '';
        }
    });
});